// PACEInterface.cpp
//
// simple object wrapper for making calls into the PACE layer from
// your PACE Native Object
//
// Copyright (C) 2002-2003 Metrowerks Corp.

#pragma warn_extracomma off

#include "PACEInterface.h"
#include "endianutils.h"

#if PACE_INTERFACE_AS_CLASS

	#define PACE_CLASS_WRAPPER(rv)		rv PACEInterface::
	#define PACE_CALLBACK_PTR			m_call68KFuncP
	#define PACE_EMULSTATE				m_emulStateP

#else

	#define PACE_CLASS_WRAPPER(rv)		extern "C" rv
	#define PACE_CALLBACK_PTR			g_call68KFuncP
	#define PACE_EMULSTATE				g_emulStateP

#endif

// local definition of the emulation state structure
struct EmulStateType
{
	UInt32 instr;
	UInt32 regData[8];
	UInt32 regAddress[8];
	UInt32 regPC;
};

#define PACE_PARAMS_INIT()						\
	UInt8 params[] = {
	
#define PACE_PARAMS_ADD8(param)					\
	(UInt8)(param),								\
	0,

#define PACE_PARAMS_ADD16(param)				\
	(UInt8)((UInt16)(param) >> 8),				\
	(UInt8)(param),

#define PACE_PARAMS_ADD32(param)				\
	(UInt8)((UInt32)(param) >> 24),				\
	(UInt8)((UInt32)(param) >> 16),				\
	(UInt8)((UInt32)(param) >> 8),				\
	(UInt8)(param),

#define PACE_SWAP_IN16(param)					\
	if (param) { *(UInt16 *)param = ByteSwap16((UInt16)*param); }

#define PACE_SWAP_IN32(param)					\
	if (param) { *(UInt32 *)param = ByteSwap32((UInt32)*param); }

#define PACE_SWAP_OUT16(param)					\
	if (param) { *(UInt16 *)param = ByteSwap16((UInt16)*param); }

#define PACE_SWAP_OUT32(param)					\
	if (param) { *(UInt32 *)param = ByteSwap32((UInt32)*param); }

// basic form
#define PACE_EXEC(trap, returnType)				\
	};											\
	return ((returnType)((PACE_CALLBACK_PTR)(	\
		static_cast<void *>(PACE_EMULSTATE),	\
		PceNativeTrapNo(trap),					\
		&params,								\
		sizeof(params))));

// pointer returning variant	
#define PACE_EXEC_RP(trap, returnType)			\
	};											\
	return ((returnType)((PACE_CALLBACK_PTR)(	\
		static_cast<void *>(PACE_EMULSTATE),	\
		PceNativeTrapNo(trap),					\
		&params,								\
		sizeof(params) | kPceNativeWantA0)));

// no return value variant
#define PACE_EXEC_NRV(trap)						\
	};											\
	PACE_CALLBACK_PTR(							\
		static_cast<void *>(PACE_EMULSTATE),	\
		PceNativeTrapNo(trap),					\
		&params,								\
		sizeof(params));
		
// no parameters version
#define PACE_EXEC_NP(trap, returnType)			\
	return ((returnType)((PACE_CALLBACK_PTR)(	\
		static_cast<void *>(PACE_EMULSTATE),	\
		PceNativeTrapNo(trap),					\
		NULL, 0)));

// no parameters, returns pointer
#define PACE_EXEC_NP_RP(trap, returnType)		\
	return ((returnType)((PACE_CALLBACK_PTR)(	\
		static_cast<void *>(PACE_EMULSTATE),	\
		PceNativeTrapNo(trap),					\
		NULL, kPceNativeWantA0)));

// no parameters, returns nothing
#define PACE_EXEC_NP_NRV(trap)					\
	(void)PACE_CALLBACK_PTR(					\
		static_cast<void *>(PACE_EMULSTATE),	\
		PceNativeTrapNo(trap),					\
		NULL, 0);

// basic form, delayed return
#define PACE_EXEC_DELAY(trap, returnType)		\
	};											\
	returnType retval =							\
		((returnType)((PACE_CALLBACK_PTR)(		\
		static_cast<void *>(PACE_EMULSTATE),	\
		PceNativeTrapNo(trap),					\
		&params,								\
		sizeof(params))));
	

// basic form, delayed return, returns pointer
#define PACE_EXEC_DELAY_RP(trap, returnType)	\
	};                                          \
    returnType retval =                         \
        ((returnType)((PACE_CALLBACK_PTR)(      \
        static_cast<void *>(PACE_EMULSTATE),    \
        PceNativeTrapNo(trap),                  \
        &params,                                \
        sizeof(params) | kPceNativeWantA0)));

// return from a delayed call
#define PACE_RETURN()							\
	return retval;

// basic VFS form
#define PACE_VFS_EXEC(vfsTrap, returnType)		\
	 };											\
	PACE_EMULSTATE->regData[2] = vfsTrap;		\
	return ((returnType)((PACE_CALLBACK_PTR)(	\
		static_cast<void *>(PACE_EMULSTATE),	\
		PceNativeTrapNo(sysTrapFileSystemDispatch), \
		&params,								\
		sizeof(params))));

// basic VFS form, delayed return
#define PACE_VFS_EXEC_DELAY(vfsTrap, returnType) \
	 };											\
	PACE_EMULSTATE->regData[2] = vfsTrap;		\
	returnType retval =							\
		((returnType)((PACE_CALLBACK_PTR)(		\
		static_cast<void *>(PACE_EMULSTATE),	\
		PceNativeTrapNo(sysTrapFileSystemDispatch), \
		&params,								\
		sizeof(params))));

// --------- IMPLEMENTATION ---------


//////////////////////////////////////////////////////////////////////////////

PACE_CLASS_WRAPPER(MemPtr) MemPtrNew(UInt32 size)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(size)
	PACE_EXEC_RP(sysTrapMemPtrNew, MemPtr)
}

PACE_CLASS_WRAPPER(Err) MemPtrFree(MemPtr ptr)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(ptr)
	PACE_EXEC(sysTrapMemChunkFree, Err)
}

PACE_CLASS_WRAPPER(Err) MemPtrUnlock(MemPtr ptr)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(ptr)
	PACE_EXEC(sysTrapMemPtrUnlock, Err)
}

PACE_CLASS_WRAPPER(Err) MemPtrResize(MemPtr ptr, UInt32 newSize)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(ptr)
	PACE_PARAMS_ADD32(newSize)
	PACE_EXEC(sysTrapMemPtrResize, Err)
}

PACE_CLASS_WRAPPER(UInt32) MemPtrSize(MemPtr ptr)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(ptr)	
	PACE_EXEC(sysTrapMemPtrSize, UInt32)
}

PACE_CLASS_WRAPPER(MemHandle) MemHandleNew(UInt32 size)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(size)
	PACE_EXEC_RP(sysTrapMemHandleNew, MemHandle)
}

PACE_CLASS_WRAPPER(Err) MemHandleFree(MemHandle handle)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(handle)
	PACE_EXEC(sysTrapMemHandleFree, Err)
}

PACE_CLASS_WRAPPER(MemPtr) MemHandleLock(MemHandle handle)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(handle)
	PACE_EXEC_RP(sysTrapMemHandleLock, MemPtr)
}

PACE_CLASS_WRAPPER(Err) MemHandleUnlock(MemHandle handle)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(handle)
	PACE_EXEC(sysTrapMemHandleUnlock, Err)
}

PACE_CLASS_WRAPPER(UInt32) MemHandleSize(MemHandle handle)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(handle)
	PACE_EXEC(sysTrapMemHandleSize, UInt32)
}

PACE_CLASS_WRAPPER(Err) MemHandleResize(MemHandle handle, UInt32 newSize)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(handle)
	PACE_PARAMS_ADD32(newSize)
	PACE_EXEC(sysTrapMemHandleResize, Err)
}

PACE_CLASS_WRAPPER(MemHandle) MemPtrRecoverHandle(MemPtr ptr)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(ptr)
	PACE_EXEC(sysTrapMemPtrRecoverHandle, MemHandle)
}

PACE_CLASS_WRAPPER(Err) MemMove(void *dstP, const void *sP, Int32 numBytes)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dstP)
	PACE_PARAMS_ADD32(sP)
	PACE_PARAMS_ADD32(numBytes)
	PACE_EXEC(sysTrapMemMove, Err)
}

PACE_CLASS_WRAPPER(Err) MemSet(void *dstP, Int32 numBytes, UInt8 value)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dstP)
	PACE_PARAMS_ADD32(numBytes)
	PACE_PARAMS_ADD8(value)
	PACE_EXEC(sysTrapMemSet, Err)
}

PACE_CLASS_WRAPPER(Int16) MemCmp(const void *s1, const void *s2, Int32 numBytes)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(s1)
	PACE_PARAMS_ADD32(s2)
	PACE_PARAMS_ADD32(numBytes)
	PACE_EXEC(sysTrapMemCmp, Int16)
}

PACE_CLASS_WRAPPER(Err) DmCreateDatabase(UInt16 cardNo, const Char *nameP, UInt32 creator, UInt32 type, Boolean resDB)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(cardNo)
	PACE_PARAMS_ADD32(nameP)
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD32(type)
	PACE_PARAMS_ADD8(resDB)
	PACE_EXEC(sysTrapDmCreateDatabase, Err)
}

PACE_CLASS_WRAPPER(DmOpenRef) DmOpenDatabase(UInt16 cardNo, LocalID dbID, UInt16 mode)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(cardNo)
	PACE_PARAMS_ADD32(dbID)
	PACE_PARAMS_ADD16(mode)
	PACE_EXEC_RP(sysTrapDmOpenDatabase, DmOpenRef)
}

PACE_CLASS_WRAPPER(DmOpenRef) DmOpenDatabaseByTypeCreator(UInt32 type, UInt32 creator, UInt16 mode)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(type)
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD16(mode)
	PACE_EXEC_RP(sysTrapDmOpenDatabaseByTypeCreator, DmOpenRef)
}

PACE_CLASS_WRAPPER(LocalID) DmFindDatabase(UInt16 cardNo, const Char *nameP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(cardNo)
	PACE_PARAMS_ADD32(nameP)
	PACE_EXEC(sysTrapDmFindDatabase, LocalID)
}

PACE_CLASS_WRAPPER(Err) DmCloseDatabase(DmOpenRef dbP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_EXEC(sysTrapDmCloseDatabase, Err)
}

PACE_CLASS_WRAPPER(MemHandle) DmGetRecord(DmOpenRef dbP, UInt16 index)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_EXEC_RP(sysTrapDmGetRecord, MemHandle)
}

PACE_CLASS_WRAPPER(MemHandle) DmQueryRecord(DmOpenRef dbP, UInt16 index)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_EXEC_RP(sysTrapDmQueryRecord, MemHandle)
}

PACE_CLASS_WRAPPER(Err) DmReleaseRecord(DmOpenRef dbP, UInt16 index, Boolean dirty)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)	
	PACE_PARAMS_ADD8(dirty)
	PACE_EXEC(sysTrapDmReleaseRecord, Err)
}

PACE_CLASS_WRAPPER(MemHandle) DmNewRecord(DmOpenRef dbP, UInt16 *atP, UInt32 size)
{
	PACE_SWAP_IN16(atP)
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD32(atP)	
	PACE_PARAMS_ADD32(size)
	PACE_EXEC_DELAY_RP(sysTrapDmNewRecord, MemHandle)
	PACE_SWAP_OUT16(atP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) DmRecordInfo(DmOpenRef dbP, UInt16 index, UInt16 *attrP, UInt32 *uniqueIDP, LocalID *chunkIDP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_PARAMS_ADD32(attrP)
	PACE_PARAMS_ADD32(uniqueIDP)
	PACE_PARAMS_ADD32(chunkIDP)
	PACE_EXEC_DELAY(sysTrapDmRecordInfo, Err)
	PACE_SWAP_OUT16(attrP)
	PACE_SWAP_OUT32(uniqueIDP)
	PACE_SWAP_OUT32(chunkIDP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) DmSetRecordInfo(DmOpenRef dbP, UInt16 index, UInt16 *attrP, UInt32 *uniqueIDP)
{
	PACE_SWAP_IN16(attrP)
	PACE_SWAP_IN32(uniqueIDP)
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_PARAMS_ADD32(attrP)
	PACE_PARAMS_ADD32(uniqueIDP)
	PACE_EXEC(sysTrapDmSetRecordInfo, Err)
}

PACE_CLASS_WRAPPER(Err) DmStrCopy(void *recordP, UInt32 offset, const Char *srcP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(recordP)
	PACE_PARAMS_ADD32(offset)
	PACE_PARAMS_ADD32(srcP)
	PACE_EXEC(sysTrapDmStrCopy, Err)
}

PACE_CLASS_WRAPPER(Err) DmWrite(void *recordP, UInt32 offset, const void *srcP, UInt32 bytes)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(recordP)
	PACE_PARAMS_ADD32(offset)
	PACE_PARAMS_ADD32(srcP)
	PACE_PARAMS_ADD32(bytes)
	PACE_EXEC(sysTrapDmWrite, Err)
}

PACE_CLASS_WRAPPER(Err) DmWriteCheck(void *recordP, UInt32 offset, UInt32 bytes)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(recordP)
	PACE_PARAMS_ADD32(offset)
	PACE_PARAMS_ADD32(bytes)
	PACE_EXEC(sysTrapDmWriteCheck, Err)
}

PACE_CLASS_WRAPPER(Err) DmSet(void *recordP, UInt32 offset, UInt32 bytes, UInt8 value)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(recordP)
	PACE_PARAMS_ADD32(offset)
	PACE_PARAMS_ADD32(bytes)
	PACE_PARAMS_ADD8(value)
	PACE_EXEC(sysTrapDmSet, Err)
}

PACE_CLASS_WRAPPER(MemHandle) DmResizeRecord(DmOpenRef dbP, UInt16 index, UInt32 newSize)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_PARAMS_ADD32(newSize)
	PACE_EXEC_RP(sysTrapDmResizeRecord, MemHandle)
}

PACE_CLASS_WRAPPER(Err) DmRemoveRecord(DmOpenRef dbP, UInt16 index)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_EXEC(sysTrapDmRemoveRecord, Err)
}
		
PACE_CLASS_WRAPPER(Err) DmDeleteRecord(DmOpenRef dbP, UInt16 index)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_EXEC(sysTrapDmDeleteRecord, Err)
}

PACE_CLASS_WRAPPER(Err) DmArchiveRecord(DmOpenRef dbP, UInt16 index)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_EXEC(sysTrapDmArchiveRecord, Err)
}

PACE_CLASS_WRAPPER(Err) DmFindRecordByID(DmOpenRef dbP, UInt32 uniqueID, UInt16 *indexP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD32(uniqueID)
	PACE_PARAMS_ADD32(indexP)
	PACE_EXEC(sysTrapDmFindRecordByID, Err)
}

PACE_CLASS_WRAPPER(Err) DmMoveRecord(DmOpenRef dbP, UInt16 from, UInt16 to)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(from)
	PACE_PARAMS_ADD16(to)
	PACE_EXEC(sysTrapDmMoveRecord, Err)
}

PACE_CLASS_WRAPPER(Err) DmDeleteDatabase(UInt16 cardNo, LocalID dbID)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(cardNo)
	PACE_PARAMS_ADD32(dbID)
	PACE_EXEC(sysTrapDmDeleteDatabase, Err)
}

PACE_CLASS_WRAPPER(Err) DmGetNextDatabaseByTypeCreator(
	Boolean newSearch, DmSearchStatePtr stateInfoP,
	UInt32	type, UInt32 creator, Boolean onlyLatestVers,
	UInt16 *cardNoP, LocalID *dbIDP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD8(newSearch)
	PACE_PARAMS_ADD32(stateInfoP)
	PACE_PARAMS_ADD32(type)
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD8(onlyLatestVers)
	PACE_PARAMS_ADD32(cardNoP)
	PACE_PARAMS_ADD32(dbIDP)
	PACE_EXEC_DELAY(sysTrapDmGetNextDatabaseByTypeCreator, Err)
	PACE_SWAP_OUT16(cardNoP)
	PACE_SWAP_OUT32(dbIDP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) DmDatabaseInfo(UInt16 cardNo, LocalID	dbID, Char *nameP,
	UInt16 *attributesP, UInt16 *versionP, UInt32 *crDateP,
	UInt32 *	modDateP, UInt32 *bckUpDateP,
	UInt32 *	modNumP, LocalID *appInfoIDP,
	LocalID *sortInfoIDP, UInt32 *typeP,
	UInt32 *creatorP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(cardNo)
	PACE_PARAMS_ADD32(dbID)
	PACE_PARAMS_ADD32(nameP)
	PACE_PARAMS_ADD32(attributesP)
	PACE_PARAMS_ADD32(versionP)
	PACE_PARAMS_ADD32(crDateP)
	PACE_PARAMS_ADD32(modDateP)
	PACE_PARAMS_ADD32(bckUpDateP)
	PACE_PARAMS_ADD32(modNumP)
	PACE_PARAMS_ADD32(appInfoIDP)
	PACE_PARAMS_ADD32(sortInfoIDP)
	PACE_PARAMS_ADD32(typeP)
	PACE_PARAMS_ADD32(creatorP)
	PACE_EXEC_DELAY(sysTrapDmDatabaseInfo, Err)
	PACE_SWAP_OUT16(attributesP)
	PACE_SWAP_OUT16(versionP)
	PACE_SWAP_OUT32(crDateP)
	PACE_SWAP_OUT32(modDateP)
	PACE_SWAP_OUT32(bckUpDateP)
	PACE_SWAP_OUT32(modNumP)
	PACE_SWAP_OUT32(appInfoIDP)
	PACE_SWAP_OUT32(sortInfoIDP)
	PACE_SWAP_OUT32(typeP)
	PACE_SWAP_OUT32(creatorP)
	PACE_RETURN()	
}

PACE_CLASS_WRAPPER(Err) DmDatabaseSize(
	UInt16 cardNo, LocalID dbID, UInt32 *numRecordsP,
	UInt32 *totalBytesP, UInt32 *dataBytesP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(cardNo)
	PACE_PARAMS_ADD32(dbID)
	PACE_PARAMS_ADD32(numRecordsP)
	PACE_PARAMS_ADD32(totalBytesP)
	PACE_PARAMS_ADD32(dataBytesP)
	PACE_EXEC_DELAY(sysTrapDmDatabaseSize, Err)
	PACE_SWAP_OUT32(numRecordsP)
	PACE_SWAP_OUT32(totalBytesP)
	PACE_SWAP_OUT32(dataBytesP)
	PACE_RETURN()	
}	

PACE_CLASS_WRAPPER(MemHandle) DmResizeResource(MemHandle resourceH, UInt32 newSize)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(resourceH)
	PACE_PARAMS_ADD32(newSize)
	PACE_EXEC(sysTrapDmResizeResource, MemHandle)	
}

PACE_CLASS_WRAPPER(MemHandle) DmGetResourceIndex(DmOpenRef dbP, UInt16 index)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_EXEC(sysTrapDmGetResourceIndex, MemHandle)	
}

PACE_CLASS_WRAPPER(MemHandle) DmGetResource(DmResType type, DmResID ID)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(type)
	PACE_PARAMS_ADD16(ID)
	PACE_EXEC(sysTrapDmGetResource, MemHandle)	
}

PACE_CLASS_WRAPPER(Err) DmReleaseResource(MemHandle rsrcH)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(rsrcH)
	PACE_EXEC(sysTrapDmReleaseResource, Err)	
}

PACE_CLASS_WRAPPER(UInt16) DmFindResource(DmOpenRef dbP, DmResType resType, DmResID resID, MemHandle resH)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD32(resType)
	PACE_PARAMS_ADD16(resID)
	PACE_PARAMS_ADD32(resH)
	PACE_EXEC(sysTrapDmFindResource, UInt16)
}

PACE_CLASS_WRAPPER(Err) DmRemoveResource(DmOpenRef dbP, UInt16 index)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dbP)
	PACE_PARAMS_ADD16(index)
	PACE_EXEC(sysTrapDmRemoveResource, Err)	
}

PACE_CLASS_WRAPPER(Err) VFSFileOpen(UInt16 volRefNum, const Char *pathNameP, UInt16 openMode, FileRef *fileRefP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(volRefNum)
	PACE_PARAMS_ADD32(pathNameP)
	PACE_PARAMS_ADD16(openMode)
	PACE_PARAMS_ADD32(fileRefP)
	PACE_VFS_EXEC_DELAY(vfsTrapFileOpen, Err)
    PACE_SWAP_OUT32(fileRefP)
    PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) VFSFileCreate(UInt16 volRefNum, const Char *pathNameP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(volRefNum)
	PACE_PARAMS_ADD32(pathNameP)
	PACE_VFS_EXEC(vfsTrapFileCreate, Err)
}

PACE_CLASS_WRAPPER(Err) VFSFileClose(FileRef fileRef)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(fileRef)
	PACE_VFS_EXEC(vfsTrapFileClose, Err)
}

PACE_CLASS_WRAPPER(Err) VFSFileRead(FileRef fileRef, UInt32 numBytes, void *bufP, UInt32 *numBytesReadP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(fileRef)
	PACE_PARAMS_ADD32(numBytes)
	PACE_PARAMS_ADD32(bufP)
	PACE_PARAMS_ADD32(numBytesReadP)
	PACE_VFS_EXEC_DELAY(vfsTrapFileRead, Err)
	PACE_SWAP_OUT32(numBytesReadP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) VFSFileSeek(FileRef fileRef, UInt16 origin, Int32 offset)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(fileRef)
	PACE_PARAMS_ADD16(origin)
	PACE_PARAMS_ADD32(offset)
	PACE_VFS_EXEC(vfsTrapFileSeek, Err)
}

PACE_CLASS_WRAPPER(Err) VFSFileTell(FileRef fileRef, UInt32 *filePosP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(fileRef)
	PACE_PARAMS_ADD32(filePosP)
	PACE_VFS_EXEC_DELAY(vfsTrapFileTell, Err)
	PACE_SWAP_OUT32(filePosP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) VFSFileReadData(FileRef fileRef, UInt32 numBytes, void *bufBaseP, UInt32 offset, UInt32 *numBytesReadP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(fileRef)
	PACE_PARAMS_ADD32(numBytes)
	PACE_PARAMS_ADD32(bufBaseP)
	PACE_PARAMS_ADD32(offset)
	PACE_PARAMS_ADD32(numBytesReadP)
	PACE_VFS_EXEC_DELAY(vfsTrapFileReadData, Err)
	PACE_SWAP_OUT32(numBytesReadP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) VFSFileWrite(FileRef fileRef, UInt32 numBytes, const void *dataP, UInt32 *numBytesWrittenP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(fileRef)
	PACE_PARAMS_ADD32(numBytes)
	PACE_PARAMS_ADD32(dataP)
	PACE_PARAMS_ADD32(numBytesWrittenP)
	PACE_VFS_EXEC_DELAY(vfsTrapFileWrite, Err)
	PACE_SWAP_OUT32(numBytesWrittenP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) VFSFileSize(FileRef fileRef, UInt32 *fileSizeP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(fileRef)
	PACE_PARAMS_ADD32(fileSizeP)
	PACE_VFS_EXEC_DELAY(vfsTrapFileSize, Err)
	PACE_SWAP_OUT32(fileSizeP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) VFSFileResize(FileRef fileRef, UInt32 newSize)
{
	PACE_PARAMS_INIT()
					
	PACE_PARAMS_ADD32(fileRef)
	PACE_PARAMS_ADD32(newSize)
	PACE_VFS_EXEC(vfsTrapFileResize, Err)
}

PACE_CLASS_WRAPPER(void) DbgMessage(const Char *aStr)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(aStr)
	PACE_EXEC_NRV(sysTrapDbgMessage)
}	

PACE_CLASS_WRAPPER(Int16) SysRandom(Int32 newSeed)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(newSeed)
	PACE_EXEC(sysTrapSysRandom, Int16)
}

PACE_CLASS_WRAPPER(void) WinSetForeColorRGB(const RGBColorType* newRgbP, RGBColorType* prevRgbP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(newRgbP)
	PACE_PARAMS_ADD32(prevRgbP)
	PACE_EXEC_NRV(sysTrapWinSetForeColorRGB)
}

PACE_CLASS_WRAPPER(void) WinDrawPixel(Coord x, Coord y)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(x)
	PACE_PARAMS_ADD16(y)
	PACE_EXEC_NRV(sysTrapWinDrawPixel)
}

PACE_CLASS_WRAPPER(void) WinPushDrawState(void)
{
	PACE_EXEC_NP_NRV(sysTrapWinPushDrawState)
}

PACE_CLASS_WRAPPER(void) WinPopDrawState(void)
{
	PACE_EXEC_NP_NRV(sysTrapWinPopDrawState)
}

PACE_CLASS_WRAPPER(WinDrawOperation) WinSetDrawMode(WinDrawOperation newMode)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD8(newMode)
	PACE_EXEC(sysTrapWinSetDrawMode, WinDrawOperation)
}

PACE_CLASS_WRAPPER(IndexedColorType) WinSetForeColor(IndexedColorType foreColor)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD8(foreColor)
	PACE_EXEC(sysTrapWinSetForeColor, IndexedColorType)
}

PACE_CLASS_WRAPPER(IndexedColorType) WinSetBackColor(IndexedColorType backColor)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD8(backColor)
	PACE_EXEC(sysTrapWinSetBackColor, IndexedColorType)
}

PACE_CLASS_WRAPPER(IndexedColorType) WinSetTextColor(IndexedColorType textColor)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD8(textColor)
	PACE_EXEC(sysTrapWinSetTextColor, IndexedColorType)
}

PACE_CLASS_WRAPPER(Err) WinPalette(UInt8 operation, Int16 startIndex,
	UInt16 paletteEntries, RGBColorType *tableP)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD8(operation)
	PACE_PARAMS_ADD16(startIndex)
	PACE_PARAMS_ADD16(paletteEntries)
	PACE_PARAMS_ADD32(tableP)
	PACE_EXEC(sysTrapWinPalette, Err)
}

PACE_CLASS_WRAPPER(void) WinDrawChar(WChar theChar, Coord x, Coord y)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD16(theChar)
	PACE_PARAMS_ADD16(x)
	PACE_PARAMS_ADD16(y)
	PACE_EXEC_NRV(sysTrapWinDrawChar)
}

PACE_CLASS_WRAPPER(void) WinDrawChars(const Char *chars, Int16 len, Coord x, Coord y)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(len)
	PACE_PARAMS_ADD16(x)
	PACE_PARAMS_ADD16(y)
	PACE_EXEC_NRV(sysTrapWinDrawChars)
}

PACE_CLASS_WRAPPER(void) WinPaintChar(WChar theChar, Coord x, Coord y)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD16(theChar)
	PACE_PARAMS_ADD16(x)
	PACE_PARAMS_ADD16(y)
	PACE_EXEC_NRV(sysTrapWinPaintChar)
}

PACE_CLASS_WRAPPER(void) WinPaintChars(const Char *chars, Int16 len, Coord x, Coord y)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(len)
	PACE_PARAMS_ADD16(x)
	PACE_PARAMS_ADD16(y)
	PACE_EXEC_NRV(sysTrapWinPaintChars)
}

PACE_CLASS_WRAPPER(void) WinDrawInvertedChars(const Char *chars, Int16 len, Coord x, Coord y)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(len)
	PACE_PARAMS_ADD16(x)
	PACE_PARAMS_ADD16(y)
	PACE_EXEC_NRV(sysTrapWinDrawInvertedChars)
}

PACE_CLASS_WRAPPER(void) WinDrawTruncChars(const Char *chars, Int16 len, Coord x, Coord y, Coord maxWidth)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(len)
	PACE_PARAMS_ADD16(x)
	PACE_PARAMS_ADD16(y)
	PACE_PARAMS_ADD16(maxWidth)
	PACE_EXEC_NRV(sysTrapWinDrawTruncChars)
}

PACE_CLASS_WRAPPER(void) WinEraseChars(const Char *chars, Int16 len, Coord x, Coord y)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(len)
	PACE_PARAMS_ADD16(x)
	PACE_PARAMS_ADD16(y)
	PACE_EXEC_NRV(sysTrapWinEraseChars)
}

PACE_CLASS_WRAPPER(void) WinInvertChars(const Char *chars, Int16 len, Coord x, Coord y)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(len)
	PACE_PARAMS_ADD16(x)
	PACE_PARAMS_ADD16(y)
	PACE_EXEC_NRV(sysTrapWinInvertChars)
}

PACE_CLASS_WRAPPER(UnderlineModeType) WinSetUnderlineMode (UnderlineModeType mode)
{
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD8(mode)
	PACE_EXEC(sysTrapWinSetUnderlineMode, UnderlineModeType)
}

PACE_CLASS_WRAPPER(Err) WinScreenMode(WinScreenModeOperation operation,
	UInt32 *widthP,	UInt32 *heightP,
	UInt32 *depthP,	Boolean *enableColorP)
{
	PACE_SWAP_IN32(widthP)
	PACE_SWAP_IN32(heightP)
	PACE_SWAP_IN32(depthP)
	PACE_PARAMS_INIT()	
	PACE_PARAMS_ADD8(operation)
	PACE_PARAMS_ADD32(widthP)
	PACE_PARAMS_ADD32(heightP)
	PACE_PARAMS_ADD32(depthP)
	PACE_PARAMS_ADD32(enableColorP)
	PACE_EXEC_DELAY(sysTrapWinScreenMode, Err)
	PACE_SWAP_OUT32(widthP)
	PACE_SWAP_OUT32(heightP)
	PACE_SWAP_OUT32(depthP)
	PACE_RETURN()
}	

PACE_CLASS_WRAPPER(WinHandle) WinSetDrawWindow(WinHandle winHandle)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(winHandle)
	PACE_EXEC_RP(sysTrapWinSetDrawWindow, WinHandle)
}

PACE_CLASS_WRAPPER(WinHandle) WinGetDrawWindow(void)
{
	PACE_EXEC_NP_RP(sysTrapWinGetDrawWindow, WinHandle)
}

PACE_CLASS_WRAPPER(void) WinPaintRectangle(const RectangleType *rP, UInt16 cornerDiam)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(rP)
	PACE_PARAMS_ADD16(cornerDiam)
	PACE_EXEC_NRV(sysTrapWinPaintRectangle)
}

PACE_CLASS_WRAPPER(void) WinDrawRectangle(const RectangleType *rP, UInt16 cornerDiam)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(rP)
	PACE_PARAMS_ADD16(cornerDiam)
	PACE_EXEC_NRV(sysTrapWinDrawRectangle)
}

PACE_CLASS_WRAPPER(void) WinEraseRectangle(const RectangleType *rP, UInt16 cornerDiam)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(rP)
	PACE_PARAMS_ADD16(cornerDiam)
	PACE_EXEC_NRV(sysTrapWinEraseRectangle)
}

PACE_CLASS_WRAPPER(void) WinInvertRectangle(const RectangleType *rP, UInt16 cornerDiam)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(rP)
	PACE_PARAMS_ADD16(cornerDiam)
	PACE_EXEC_NRV(sysTrapWinInvertRectangle)
}

PACE_CLASS_WRAPPER(void) WinFillRectangle(const RectangleType *rP, UInt16 cornerDiam)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(rP)
	PACE_PARAMS_ADD16(cornerDiam)
	PACE_EXEC_NRV(sysTrapWinFillRectangle)
}

PACE_CLASS_WRAPPER(void) WinScrollRectangle(
	const RectangleType *rP, WinDirectionType direction,
	Coord distance, RectangleType *vacatedP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(rP)
	PACE_PARAMS_ADD8(direction)
	PACE_PARAMS_ADD16(distance)
	PACE_PARAMS_ADD32(vacatedP)
	PACE_EXEC_NRV(sysTrapWinScrollRectangle)
}

PACE_CLASS_WRAPPER(Boolean) EvtEventAvail(void)
{
	PACE_EXEC_NP(sysTrapEvtEventAvail, Boolean)
}

PACE_CLASS_WRAPPER(UInt16) FrmAlert (UInt16 alertId)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(alertId)
	PACE_EXEC(sysTrapFrmAlert,UInt16)
}

PACE_CLASS_WRAPPER(UInt16) FrmCustomAlert(UInt16 alertId, const Char *s1, const Char *s2, const Char *s3)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(alertId)
	PACE_PARAMS_ADD32(s1)
	PACE_PARAMS_ADD32(s2)
	PACE_PARAMS_ADD32(s3)
	PACE_EXEC(sysTrapFrmCustomAlert,UInt16)
}

PACE_CLASS_WRAPPER(Char *) StrIToA(Char *s, Int32 i)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(s)
	PACE_PARAMS_ADD32(i)
	PACE_EXEC_RP(sysTrapStrIToA,Char*)
}

PACE_CLASS_WRAPPER(Char *) StrIToH(Char *s, UInt32 i)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(s)
	PACE_PARAMS_ADD32(i)
	PACE_EXEC_RP(sysTrapStrIToH,Char*)
}

PACE_CLASS_WRAPPER(Char *) StrChr (const Char *str, WChar chr)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(str)
	PACE_PARAMS_ADD16(chr)
	PACE_EXEC_RP(sysTrapStrChr,Char*)
}

PACE_CLASS_WRAPPER(Char *) StrStr (const Char *str, const Char *token)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(str)
	PACE_PARAMS_ADD32(token)
	PACE_EXEC_RP(sysTrapStrStr,Char*)
}

PACE_CLASS_WRAPPER(Char *) StrCopy(Char *dst, const Char *src)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dst)
	PACE_PARAMS_ADD32(src)
	PACE_EXEC_RP(sysTrapStrCopy,Char*)
}

PACE_CLASS_WRAPPER(Char *) StrNCopy(Char *dst, const Char *src, Int16 n)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dst)
	PACE_PARAMS_ADD32(src)
	PACE_PARAMS_ADD16(n)
	PACE_EXEC_RP(sysTrapStrNCopy,Char*)
}

PACE_CLASS_WRAPPER(Char *) StrCat(Char *dst, const Char *src)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dst)
	PACE_PARAMS_ADD32(src)
	PACE_EXEC_RP(sysTrapStrCat,Char*)
}
							
PACE_CLASS_WRAPPER(Char *) StrNCat(Char *dst, const Char *src, Int16 n)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dst)
	PACE_PARAMS_ADD32(src)
	PACE_PARAMS_ADD16(n)
	PACE_EXEC_RP(sysTrapStrNCat,Char*)
}
							
PACE_CLASS_WRAPPER(UInt16) StrLen(const Char *src)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(src)
	PACE_EXEC(sysTrapStrLen,UInt16)
}
							
PACE_CLASS_WRAPPER(Int16) StrCompareAscii(const Char *s1, const Char *s2)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(s1)
	PACE_PARAMS_ADD32(s2)
	PACE_EXEC(sysTrapStrCompareAscii,Int16)
}

PACE_CLASS_WRAPPER(Int16) StrCompare(const Char *s1, const Char *s2)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(s1)
	PACE_PARAMS_ADD32(s2)
	PACE_EXEC(sysTrapStrCompare,Int16)
}

PACE_CLASS_WRAPPER(Int16) StrNCompareAscii(const Char *s1, const Char *s2, Int32 n)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(s1)
	PACE_PARAMS_ADD32(s2)
	PACE_PARAMS_ADD32(n)
	PACE_EXEC(sysTrapStrNCompareAscii,Int16)
}

PACE_CLASS_WRAPPER(Int16) StrNCompare(const Char *s1, const Char *s2, Int32 n)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(s1)
	PACE_PARAMS_ADD32(s2)
	PACE_PARAMS_ADD32(n)
	PACE_EXEC(sysTrapStrNCompare,Int16)
}

PACE_CLASS_WRAPPER(Int16) StrCaselessCompare(const Char *s1, const Char *s2)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(s1)
	PACE_PARAMS_ADD32(s2)
	PACE_EXEC(sysTrapStrCaselessCompare,Int16)
}

PACE_CLASS_WRAPPER(Int16) StrNCaselessCompare(const Char *s1, const Char *s2, Int32 n)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(s1)
	PACE_PARAMS_ADD32(s2)
	PACE_PARAMS_ADD32(n)
	PACE_EXEC(sysTrapStrNCaselessCompare,Int16)
}

PACE_CLASS_WRAPPER(Char *) StrToLower(Char *dst, const Char *src)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(dst)
	PACE_PARAMS_ADD32(src)
	PACE_EXEC_RP(sysTrapStrToLower,Char*)
}

PACE_CLASS_WRAPPER(UInt32) TimGetSeconds(void)
{
	PACE_EXEC_NP(sysTrapTimGetSeconds, UInt32)
}


PACE_CLASS_WRAPPER(Int16) PrefGetAppPreferences(
	UInt32 creator,UInt16 id, void *prefs, UInt16 *prefsSize, Boolean saved)
{
	PACE_SWAP_IN16(prefsSize)
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD16(id)
	PACE_PARAMS_ADD32(prefs)
	PACE_PARAMS_ADD32(prefsSize)
	PACE_PARAMS_ADD8(saved)
	PACE_EXEC_DELAY(sysTrapPrefGetAppPreferences, Int16)
	PACE_SWAP_OUT16(prefsSize)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(void) PrefSetAppPreferences(
	UInt32 creator,UInt16 id, Int16 version, const void *prefs,
	UInt16 prefsSize, Boolean saved)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD16(id)
	PACE_PARAMS_ADD16(version)
	PACE_PARAMS_ADD32(prefs)
	PACE_PARAMS_ADD16(prefsSize)
	PACE_PARAMS_ADD8(saved)
	PACE_EXEC_NRV(sysTrapPrefSetAppPreferences)
}

PACE_CLASS_WRAPPER(UInt16) SysFatalAlert(const Char *msg)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(msg)
	PACE_EXEC(sysTrapSysFatalAlert, UInt16)
}

PACE_CLASS_WRAPPER(Err) FtrGet(UInt32 creator, UInt16 featureNum, UInt32 *valueP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD16(featureNum)
	PACE_PARAMS_ADD32(valueP)
	PACE_EXEC_DELAY(sysTrapFtrGet, Err)
	PACE_SWAP_OUT32(valueP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) FtrSet(UInt32 creator, UInt16 featureNum, UInt32 newValue)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD16(featureNum)
	PACE_PARAMS_ADD32(newValue)
	PACE_EXEC(sysTrapFtrSet, Err)
}

PACE_CLASS_WRAPPER(Err) FtrUnregister(UInt32 creator, UInt16 featureNum)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD16(featureNum)
	PACE_EXEC(sysTrapFtrUnregister, Err)
}

PACE_CLASS_WRAPPER(Err) FtrGetByIndex(UInt16 index, Boolean romTable,
				UInt32 *creatorP, UInt16 *numP, UInt32 *valueP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(index)
	PACE_PARAMS_ADD8(romTable)
	PACE_PARAMS_ADD32(creatorP)
	PACE_PARAMS_ADD32(numP)
	PACE_PARAMS_ADD32(valueP)
	PACE_EXEC_DELAY(sysTrapFtrGetByIndex, Err)
	PACE_SWAP_OUT32(creatorP)
	PACE_SWAP_OUT16(numP)
	PACE_SWAP_OUT32(valueP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) FtrPtrNew(UInt32 creator, UInt16 featureNum, UInt32 size,
				void **newPtrP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD16(featureNum)
	PACE_PARAMS_ADD32(size)
	PACE_PARAMS_ADD32(newPtrP)
	PACE_EXEC_DELAY(sysTrapFtrPtrNew, Err)
	PACE_SWAP_OUT32(newPtrP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) FtrPtrFree(UInt32 creator, UInt16 featureNum)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD16(featureNum)
	PACE_EXEC(sysTrapFtrPtrFree, Err)
}

PACE_CLASS_WRAPPER(Err) FtrPtrResize(UInt32 creator, UInt16 featureNum, UInt32 newSize,
				void **newPtrP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD16(featureNum)
	PACE_PARAMS_ADD32(newSize)
	PACE_PARAMS_ADD32(newPtrP)
	PACE_EXEC_DELAY(sysTrapFtrPtrResize, Err)
	PACE_SWAP_OUT32(newPtrP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(FontID) FntGetFont (void)
{
	PACE_EXEC_NP(sysTrapFntGetFont, FontID)
}

PACE_CLASS_WRAPPER(FontID) FntSetFont (FontID font)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD8(font)
	PACE_EXEC(sysTrapFntSetFont, FontID)
}

PACE_CLASS_WRAPPER(FontPtr) FntGetFontPtr (void)
{
	PACE_EXEC_NP_RP(sysTrapFntGetFontPtr, FontPtr)
}

PACE_CLASS_WRAPPER(Int16) FntBaseLine (void)
{
	PACE_EXEC_NP(sysTrapFntBaseLine, Int16)
}

PACE_CLASS_WRAPPER(Int16) FntCharHeight (void)
{
	PACE_EXEC_NP(sysTrapFntCharHeight, Int16)
}

PACE_CLASS_WRAPPER(Int16) FntLineHeight (void)
{
	PACE_EXEC_NP(sysTrapFntLineHeight, Int16)
}

PACE_CLASS_WRAPPER(Int16) FntAverageCharWidth (void)
{
	PACE_EXEC_NP(sysTrapFntAverageCharWidth, Int16)
}

PACE_CLASS_WRAPPER(Int16) FntCharWidth (Char ch)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD8(ch)
	PACE_EXEC(sysTrapFntCharWidth, Int16)
}

PACE_CLASS_WRAPPER(Int16) FntWCharWidth (WChar iChar)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(iChar)
	PACE_EXEC(sysTrapFntWCharWidth, Int16)
}

PACE_CLASS_WRAPPER(Int16) FntCharsWidth (Char const *chars, Int16 len)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(len)
	PACE_EXEC(sysTrapFntCharsWidth, Int16)
}

PACE_CLASS_WRAPPER(Int16) FntWidthToOffset (Char const *pChars, UInt16 length,
	Int16 pixelWidth, Boolean *leadingEdge, Int16 *truncWidth)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(pChars)
	PACE_PARAMS_ADD16(length)
	PACE_PARAMS_ADD16(pixelWidth)
	PACE_PARAMS_ADD32(leadingEdge)
	PACE_PARAMS_ADD32(truncWidth)
	PACE_EXEC_DELAY(sysTrapFntWidthToOffset, Int16)
	PACE_SWAP_OUT16(truncWidth)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(void) FntCharsInWidth (Char const *string,
	Int16 *stringWidthP, Int16 *stringLengthP,
	Boolean *fitWithinWidth)
{
	PACE_SWAP_IN16(stringWidthP)
	PACE_SWAP_IN16(stringLengthP)
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(string)
	PACE_PARAMS_ADD32(stringWidthP)
	PACE_PARAMS_ADD32(stringLengthP)
	PACE_PARAMS_ADD32(fitWithinWidth)
	PACE_EXEC_NRV(sysTrapFntCharsInWidth)
	PACE_SWAP_OUT16(stringWidthP)
	PACE_SWAP_OUT16(stringLengthP)
}

PACE_CLASS_WRAPPER(Int16) FntDescenderHeight (void)
{
	PACE_EXEC_NP(sysTrapFntDescenderHeight, Int16)
}

PACE_CLASS_WRAPPER(Int16) FntLineWidth (Char const *pChars, UInt16 length)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(pChars)
	PACE_PARAMS_ADD16(length)
	PACE_EXEC(sysTrapFntLineWidth, Int16)
}

PACE_CLASS_WRAPPER(UInt16) FntWordWrap (Char const *chars, UInt16 maxWidth)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(maxWidth)
	PACE_EXEC(sysTrapFntWordWrap, UInt16)
}

PACE_CLASS_WRAPPER(void) FntWordWrapReverseNLines (Char const *const chars,
	UInt16 maxWidth, UInt16 *linesToScrollP, UInt16 *scrollPosP)
{
	PACE_SWAP_IN16(linesToScrollP)
	PACE_SWAP_IN16(scrollPosP)
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(maxWidth)
	PACE_PARAMS_ADD32(linesToScrollP)
	PACE_PARAMS_ADD32(scrollPosP)
	PACE_EXEC_NRV(sysTrapFntWordWrapReverseNLines)
	PACE_SWAP_OUT16(linesToScrollP)
	PACE_SWAP_OUT16(scrollPosP)
}

PACE_CLASS_WRAPPER(void) FntGetScrollValues (Char const *chars, UInt16 width,
	UInt16 scrollPos, UInt16 *linesP, UInt16 *topLine)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(chars)
	PACE_PARAMS_ADD16(width)
	PACE_PARAMS_ADD16(scrollPos)
	PACE_PARAMS_ADD32(linesP)
	PACE_PARAMS_ADD32(topLine)
	PACE_EXEC_NRV(sysTrapFntGetScrollValues)
	PACE_SWAP_OUT16(linesP)
	PACE_SWAP_OUT16(topLine)
}

PACE_CLASS_WRAPPER(Err) FntDefineFont (FontID font, FontPtr fontP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD8(font)
	PACE_PARAMS_ADD32(fontP)
	PACE_EXEC(sysTrapFntDefineFont, Err)
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

/// HEROCRAFT HACK BEGIN ///

PACE_CLASS_WRAPPER(Err) EvtResetAutoOffTimer(void)
{
	PACE_EXEC_NP( sysTrapKeyCurrentState, Err )
}

PACE_CLASS_WRAPPER(void) WinSetBackColorRGB(const RGBColorType* newRgbP, RGBColorType* prevRgbP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(newRgbP)
	PACE_PARAMS_ADD32(prevRgbP)
	PACE_EXEC_NRV(sysTrapWinSetBackColorRGB)
}


PACE_CLASS_WRAPPER(void) WinGetDisplayExtent (Coord *extentX, Coord *extentY)
{
	PACE_SWAP_IN16(extentX)
	PACE_SWAP_IN16(extentY)
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(extentX)
	PACE_PARAMS_ADD32(extentY)
	PACE_EXEC_NRV(sysTrapWinGetDisplayExtent)
	PACE_SWAP_OUT16(extentX)
	PACE_SWAP_OUT16(extentY)
}	


PACE_CLASS_WRAPPER(void) EvtGetPen(Int16 *pScreenX, Int16 *pScreenY, Boolean *pPenDown)
{
	PACE_SWAP_IN16(pScreenX)
	PACE_SWAP_IN16(pScreenY)
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(pScreenX)
	PACE_PARAMS_ADD32(pScreenY)
	PACE_PARAMS_ADD32(pPenDown)
	PACE_EXEC_NRV(sysTrapEvtGetPen)
	PACE_SWAP_OUT16(pScreenX)
	PACE_SWAP_OUT16(pScreenY)
}	

PACE_CLASS_WRAPPER(MemPtr) BmpGetBits (BitmapType * bitmapP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(bitmapP)
	PACE_EXEC_RP(sysTrapBmpGetBits, MemPtr)
}

PACE_CLASS_WRAPPER(void) EvtAddEventToQueue (const EventType *event)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(event)
	PACE_EXEC_NRV(sysTrapEvtAddEventToQueue)
}	

PACE_CLASS_WRAPPER(void) EvtGetEvent (EventType *event, Int32 timeout)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(event)
	PACE_PARAMS_ADD32(timeout)
	PACE_EXEC_NRV(sysTrapEvtGetEvent)
}	

PACE_CLASS_WRAPPER(void) FrmCloseAllForms(void)
{
	PACE_EXEC_NP_NRV(sysTrapFrmCloseAllForms)
}

PACE_CLASS_WRAPPER(Boolean) FrmDispatchEvent (EventType *eventP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(eventP)
	PACE_EXEC(sysTrapFrmDispatchEvent,Boolean)
}

PACE_CLASS_WRAPPER(void) FrmDrawForm (FormType *formP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(formP)
	PACE_EXEC_NRV(sysTrapFrmDrawForm)
}	

PACE_CLASS_WRAPPER(FormType *) FrmGetActiveForm(void)
{
	PACE_EXEC_NP_RP(sysTrapFrmGetActiveForm, FormType*)
}

PACE_CLASS_WRAPPER(FormType *) FrmGetFirstForm(void)
{
	PACE_EXEC_NP_RP(sysTrapFrmGetFirstForm, FormType*)
}

//!!!
PACE_CLASS_WRAPPER(void) FrmGetFormBounds (const FormType *formP, RectangleType *rP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(formP)
	PACE_PARAMS_ADD32(rP)
	PACE_EXEC_NRV(sysTrapFrmGetFormBounds)
}	

PACE_CLASS_WRAPPER(FormType*) FrmGetFormPtr (UInt16 formId)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(formId)
	PACE_EXEC_RP(sysTrapFrmGetFormPtr, FormType *)
}

PACE_CLASS_WRAPPER(void) FrmGotoForm (UInt16 formId)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(formId)
	PACE_EXEC_NRV(sysTrapFrmGotoForm)
}	

PACE_CLASS_WRAPPER(FormType*) FrmInitForm (UInt16 rscID)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(rscID)
	PACE_EXEC_RP(sysTrapFrmInitForm, FormType *)
}

PACE_CLASS_WRAPPER(void) FrmSetActiveForm (FormType *formP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(formP)
	PACE_EXEC_NRV(sysTrapFrmSetActiveForm)
}	

PACE_CLASS_WRAPPER(void) FrmSetEventHandler (FormType *formP, FormEventHandlerType *handler)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(formP)
	PACE_PARAMS_ADD32(handler)
	PACE_EXEC_NRV(sysTrapFrmSetEventHandler)
}	

PACE_CLASS_WRAPPER(UInt32) KeyCurrentState(void)
{
	PACE_EXEC_NP(sysTrapKeyCurrentState, UInt32)
}

PACE_CLASS_WRAPPER(UInt32) KeySetMask(UInt32 keyMask)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(keyMask)
	PACE_EXEC(sysTrapKeySetMask,UInt32)
}

PACE_CLASS_WRAPPER(Boolean) MenuHandleEvent (MenuBarType *menuP, EventType *event, UInt16 *error)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(menuP)
	PACE_PARAMS_ADD32(event)
	PACE_PARAMS_ADD32(error)
	PACE_EXEC_DELAY(sysTrapMenuHandleEvent,Boolean)
	PACE_SWAP_OUT16(error)
	PACE_RETURN()	
}

PACE_CLASS_WRAPPER(Boolean) SysHandleEvent(EventPtr eventP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(eventP)
	PACE_EXEC(sysTrapSysHandleEvent,Boolean)
}

PACE_CLASS_WRAPPER(UInt16) SysTicksPerSecond(void)
{
	PACE_EXEC_NP(sysTrapSysTicksPerSecond, UInt16)
}

PACE_CLASS_WRAPPER(UInt32) TimGetTicks(void)
{
	PACE_EXEC_NP(sysTrapTimGetTicks, UInt32)
}

PACE_CLASS_WRAPPER(void) WinCopyRectangle (WinHandle srcWin, WinHandle dstWin, const RectangleType *srcRect, Coord destX, Coord destY, WinDrawOperation mode)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(srcWin)
	PACE_PARAMS_ADD32(dstWin)
	PACE_PARAMS_ADD32(srcRect)
	PACE_PARAMS_ADD16(destX)
	PACE_PARAMS_ADD16(destY)
	PACE_PARAMS_ADD8(mode)	
	PACE_EXEC_NRV(sysTrapWinCopyRectangle)
}	

PACE_CLASS_WRAPPER(WinHandle) WinCreateOffscreenWindow (Coord width, Coord height,
WindowFormatType format, UInt16 *error)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(width)
	PACE_PARAMS_ADD16(height)
	PACE_PARAMS_ADD8(format)
	PACE_PARAMS_ADD32(error)
	PACE_EXEC_DELAY_RP(sysTrapWinCreateOffscreenWindow,WinHandle)
	PACE_SWAP_OUT16(error)
	PACE_RETURN()
}	

PACE_CLASS_WRAPPER(void) WinDeleteWindow (WinHandle winHandle, Boolean eraseIt)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(winHandle)
	PACE_PARAMS_ADD8(eraseIt)
	PACE_EXEC_NRV(sysTrapWinDeleteWindow)
}

PACE_CLASS_WRAPPER(BitmapType *) WinGetBitmap (WinHandle winHandle)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(winHandle)
	PACE_EXEC_RP(sysTrapWinGetBitmap,BitmapType *)
}	


PACE_CLASS_WRAPPER(Err) FileDelete(UInt16 cardNo, const Char *nameP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(cardNo)
	PACE_PARAMS_ADD32(nameP)
	PACE_EXEC(sysTrapFileDelete, Err)
}

PACE_CLASS_WRAPPER(FileHand) FileOpen(UInt16 cardNo, const Char * nameP, UInt32 type, UInt32 creator, UInt32 openMode, Err *errP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(cardNo)
	PACE_PARAMS_ADD32(nameP)
	PACE_PARAMS_ADD32(type)
	PACE_PARAMS_ADD32(creator)
	PACE_PARAMS_ADD32(openMode)
	PACE_PARAMS_ADD32(errP)
	PACE_EXEC_DELAY_RP(sysTrapFileOpen, FileHand)
    PACE_SWAP_OUT32(errP)
    PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) FileClose(FileHand stream)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(stream)
	PACE_EXEC(sysTrapFileClose, Err)
}

PACE_CLASS_WRAPPER(Int32) FileWrite(FileHand stream, const void *dataP, Int32 objSize, Int32 numObj, Err *errP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(stream)
	PACE_PARAMS_ADD32(dataP)
	PACE_PARAMS_ADD32(objSize)
	PACE_PARAMS_ADD32(numObj)
	PACE_PARAMS_ADD32(errP)
	PACE_EXEC_DELAY(sysTrapFileWrite, Int32)
    PACE_SWAP_OUT32(errP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Int32) FileReadLow(FileHand stream, void *baseP, Int32 offset, Boolean dataStoreBased, Int32 objSize, Int32 numObj, Err *errP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(stream)
	PACE_PARAMS_ADD32(baseP)
	PACE_PARAMS_ADD32(offset)
	PACE_PARAMS_ADD8(dataStoreBased)
	PACE_PARAMS_ADD32(objSize)
	PACE_PARAMS_ADD32(numObj)
	PACE_PARAMS_ADD32(errP)
	PACE_EXEC_DELAY(sysTrapFileReadLow, Int32)
    PACE_SWAP_OUT32(errP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(MemPtr) MemChunkNew(UInt16 heapID, UInt32 size, UInt16 attr)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(heapID)
	PACE_PARAMS_ADD32(size)
	PACE_PARAMS_ADD16(attr)
	PACE_EXEC_RP(sysTrapMemChunkNew, MemPtr)
}

PACE_CLASS_WRAPPER(WinHandle) WinGetDisplayWindow(void)
{
	PACE_EXEC_NP_RP(sysTrapWinGetDisplayWindow, WinHandle)
}

/// file system
PACE_CLASS_WRAPPER(Err) FileControl(FileOpEnum op, FileHand stream,
	void *valueP, Int32 *valueLenP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD8(op)
	PACE_PARAMS_ADD32(stream)
	PACE_PARAMS_ADD32(valueP)
	PACE_PARAMS_ADD32(valueLenP)
	PACE_EXEC_DELAY(sysTrapFileControl, Err)
	PACE_SWAP_OUT32(valueLenP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) FileSeek(FileHand stream, Int32 offset, FileOriginEnum origin)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(stream)
	PACE_PARAMS_ADD32(offset)
	PACE_PARAMS_ADD8(origin)
	PACE_EXEC(sysTrapFileSeek, Err)
}


PACE_CLASS_WRAPPER(Err) FileTruncate(FileHand stream, Int32 newSize)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(stream)
	PACE_PARAMS_ADD32(newSize)
	PACE_EXEC(sysTrapFileTruncate, Err)
}

PACE_CLASS_WRAPPER(Int32) FileTell(FileHand stream, Int32 *fileSizeP, Err *errP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(stream)
	PACE_PARAMS_ADD32(fileSizeP)
	PACE_PARAMS_ADD32(errP)
	PACE_EXEC_DELAY(sysTrapFileTell, Int32)
	PACE_SWAP_OUT32(fileSizeP)
	PACE_SWAP_OUT32(errP)
	PACE_RETURN()
}

/// HotSync
PACE_CLASS_WRAPPER(Err) DlkGetSyncInfo(UInt32 *succSyncDateP, UInt32 *lastSyncDateP,
	DlkSyncStateType *syncStateP, Char *nameBufP, Char *logBufP, Int32 *logLenP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(succSyncDateP)
	PACE_PARAMS_ADD32(lastSyncDateP)
	PACE_PARAMS_ADD32(syncStateP)
	PACE_PARAMS_ADD32(nameBufP)
	PACE_PARAMS_ADD32(logBufP)
	PACE_PARAMS_ADD32(logLenP)
	PACE_EXEC(sysTrapDlkGetSyncInfo, Err)
}

PACE_CLASS_WRAPPER(Int32) StrAToI (const Char *str)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(str)
	PACE_EXEC(sysTrapStrAToI, Int32)
}

////////////////////////////////////////////////////////////////
/// BLUETOOTH Start {
////////////////////////////////////////////////////////////////

//notification callback related
PACE_CLASS_WRAPPER(Err) BtLibRegisterManagementNotification (UInt16 btLibRefNum,
		BtLibManagementProcPtr callbackP, UInt32 refCon)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(callbackP)
	PACE_PARAMS_ADD32(refCon)
	PACE_EXEC(btLibTrapRegisterManagementNotification, Err)
}


PACE_CLASS_WRAPPER(Err) BtLibUnregisterManagementNotification(UInt16 btLibRefNum,
	BtLibManagementProcPtr callbackP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(callbackP)
	PACE_EXEC(btLibTrapUnregisterManagementNotification, Err)
}

//piconet related
PACE_CLASS_WRAPPER(Err) BtLibPiconetCreate (UInt16 btLibRefNum,
	Boolean unlockInbound, Boolean discoverable)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD8(unlockInbound)
	PACE_PARAMS_ADD8(discoverable)
	PACE_EXEC(btLibTrapPiconetCreate, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibPiconetDestroy(UInt16 btLibRefNum)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_EXEC(btLibTrapPiconetDestroy, Err)
}

//inquiry related
PACE_CLASS_WRAPPER(Err) BtLibStartInquiry(UInt16 btLibRefNum,  UInt8 timeOut, UInt8 maxResp)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD8(timeOut)
	PACE_PARAMS_ADD8(maxResp)
	PACE_EXEC(btLibTrapStartInquiry, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibCancelInquiry(UInt16 btLibRefNum)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_EXEC(btLibTrapCancelInquiry, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibGetRemoteDeviceName(UInt16 btLibRefNum,
		BtLibDeviceAddressTypePtr remoteDeviceP,
		BtLibFriendlyNameType* nameP, BtLibGetNameEnum retrievalMethod)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(remoteDeviceP)
	PACE_PARAMS_ADD32(nameP)
	PACE_PARAMS_ADD8(retrievalMethod)
	PACE_EXEC(btLibTrapGetRemoteDeviceName, Err)
}

//ACL link related
PACE_CLASS_WRAPPER(Err) BtLibLinkConnect(UInt16 btLibRefNum,
		BtLibDeviceAddressTypePtr remoteDeviceP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(remoteDeviceP)
	PACE_EXEC(btLibTrapLinkConnect, Err)
}	

PACE_CLASS_WRAPPER(Err) BtLibLinkDisconnect(UInt16 btLibRefNum,
		BtLibDeviceAddressTypePtr remoteDeviceP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(remoteDeviceP)
	PACE_EXEC(btLibTrapLinkDisconnect, Err)
}

//socket related
PACE_CLASS_WRAPPER(Err) BtLibSocketCreate(UInt16 btLibRefNum,
	BtLibSocketRef* socketRefP, BtLibSocketProcPtr callbackP,
	UInt32 refCon, BtLibProtocolEnum socketProtocol)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(socketRefP)
	PACE_PARAMS_ADD32(callbackP)
	PACE_PARAMS_ADD32(refCon)
	PACE_PARAMS_ADD8(socketProtocol)
	PACE_EXEC_DELAY(btLibTrapSocketCreate, Err)
	PACE_SWAP_OUT16(socketRefP)
	PACE_RETURN()
}	

PACE_CLASS_WRAPPER(Err) BtLibSocketClose(UInt16 btLibRefNum, BtLibSocketRef socket)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD16(socket)
	PACE_EXEC(btLibTrapSocketClose, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibSocketListen(UInt16 btLibRefNum,
		BtLibSocketRef socket, BtLibSocketListenInfoType *listenInfo)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD16(socket)
	PACE_PARAMS_ADD32(listenInfo)
	PACE_EXEC(btLibTrapSocketListen, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibSocketConnect(UInt16 btLibRefNum,
		BtLibSocketRef socket, BtLibSocketConnectInfoType* connectInfo)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD16(socket)	
	PACE_PARAMS_ADD32(connectInfo)
	PACE_EXEC(btLibTrapSocketConnect, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibSocketRespondToConnection(UInt16 btLibRefNum,
		BtLibSocketRef socket, Boolean accept)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD16(socket)	
	PACE_PARAMS_ADD8(accept)
	PACE_EXEC(btLibTrapSocketRespondToConnection, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibSocketSend(UInt16 btLibRefNum, BtLibSocketRef socket,
		UInt8 *data, UInt32 dataLen)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD16(socket)
	PACE_PARAMS_ADD32(data)
	PACE_PARAMS_ADD32(dataLen)
	PACE_EXEC(btLibTrapSocketSend, Err)
}


PACE_CLASS_WRAPPER(Err) BtLibSocketAdvanceCredit(UInt16 btLibRefNum,
		BtLibSocketRef socket, UInt8 credit)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD16(socket)
	PACE_PARAMS_ADD8(credit)
	PACE_EXEC(btLibTrapSocketAdvanceCredit, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibSocketGetInfo(UInt16 btLibRefNum, BtLibSocketRef socket,
		BtLibSocketInfoEnum infoType, void * valueP, UInt32 valueSize)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD16(socket)	
	PACE_PARAMS_ADD16(infoType)
	PACE_PARAMS_ADD32(valueP)
	PACE_PARAMS_ADD32(valueSize)	
	PACE_EXEC(btLibTrapSocketGetInfo, Err)
}


// sdp related
PACE_CLASS_WRAPPER(Err) BtLibSdpGetServerChannelByUuid(UInt16 btLibRefNum,
	BtLibSocketRef socket, BtLibDeviceAddressType *rDev,
	BtLibSdpUuidType* serviceUUIDList, UInt8 uuidListLen)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD16(socket)
	PACE_PARAMS_ADD32(rDev)
	PACE_PARAMS_ADD32(serviceUUIDList)
	PACE_PARAMS_ADD8(uuidListLen)
	PACE_EXEC(btLibTrapSdpGetGetServerChannelByUuid, Err)		
}

PACE_CLASS_WRAPPER(Err) BtLibSdpServiceRecordCreate(UInt16 btLibRefNum,
	BtLibSdpRecordHandle* recordH)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(recordH)
	PACE_EXEC_DELAY(btLibTrapSdpServiceRecordCreate, Err)
	PACE_SWAP_OUT32(recordH)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) BtLibSdpServiceRecordDestroy(UInt16 btLibRefNum,
	BtLibSdpRecordHandle recordH)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(recordH)	
	PACE_EXEC(btLibTrapSdpServiceRecordDestroy, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibSdpServiceRecordStartAdvertising(UInt16 btLibRefNum,
	BtLibSdpRecordHandle recordH)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(recordH)	
	PACE_EXEC(btLibTrapSdpServiceRecordStartAdvertising, Err)
}

PACE_CLASS_WRAPPER(Err) BtLibSdpServiceRecordStopAdvertising(UInt16 btLibRefNum,
	BtLibSdpRecordHandle recordH)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD32(recordH)	
	PACE_EXEC(btLibTrapSdpServiceRecordStopAdvertising, Err)	
}

PACE_CLASS_WRAPPER(Err) BtLibSdpServiceRecordSetAttributesForSocket(UInt16 btLibRefNum,
	BtLibSocketRef socket, BtLibSdpUuidType* serviceUUIDList, UInt8 uuidListLen,
	const Char* serviceName, UInt16 serviceNameLen, BtLibSdpRecordHandle recordH)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(btLibRefNum)
	PACE_PARAMS_ADD16(socket)	
	PACE_PARAMS_ADD32(serviceUUIDList)
	PACE_PARAMS_ADD8(uuidListLen)
	PACE_PARAMS_ADD32(serviceName)
	PACE_PARAMS_ADD16(serviceNameLen)
	PACE_PARAMS_ADD32(recordH)	
	PACE_EXEC(btLibTrapSdpServiceRecordSetAttributesForSocket, Err)
}


////////////////////////////////////////////////////////////////
// } BLUETOOTH End
////////////////////////////////////////////////////////////////

///memory
PACE_CLASS_WRAPPER(Err) MemHeapFreeBytes(UInt16 heapID, UInt32 *freeP, UInt32 *maxP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(heapID)
	PACE_PARAMS_ADD32(freeP)
	PACE_PARAMS_ADD32(maxP)
	PACE_EXEC_DELAY(sysTrapMemHeapFreeBytes, Err)
	PACE_SWAP_OUT32(freeP)
	PACE_SWAP_OUT32(maxP)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(UInt16) MemHeapID(UInt16 cardNo, UInt16 heapIndex)
{
PACE_PARAMS_INIT()
PACE_PARAMS_ADD16(cardNo)
PACE_PARAMS_ADD16(heapIndex)
PACE_EXEC(sysTrapMemHeapID, UInt16)
}


/// sound
PACE_CLASS_WRAPPER(Err) SndStreamCreate (SndStreamRef *stream, SndStreamMode mode, UInt32 sampleRate,
				SndSampleType type, SndStreamWidth width, SndStreamBufferCallback callback,
				void *callbackArg, UInt32 bufferSize, Boolean callbackIsARM)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(stream)
	PACE_PARAMS_ADD8(mode)
	PACE_PARAMS_ADD32(sampleRate)
	PACE_PARAMS_ADD16(type)
	PACE_PARAMS_ADD8(width)
	PACE_PARAMS_ADD32(callback)
	PACE_PARAMS_ADD32(callbackArg)
	PACE_PARAMS_ADD32(bufferSize)
	PACE_PARAMS_ADD8(callbackIsARM)
	PACE_EXEC_DELAY(sysTrapSndStreamCreate, Err)
	PACE_SWAP_OUT32(stream)
	PACE_RETURN()	
}


PACE_CLASS_WRAPPER(Err) SndStreamDelete(SndStreamRef channel)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(channel)
	PACE_EXEC(sysTrapSndStreamDelete, Err)
}


PACE_CLASS_WRAPPER(Err) SndStreamStart(SndStreamRef channel)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(channel)	
	PACE_EXEC(sysTrapSndStreamStart, Err)
}


PACE_CLASS_WRAPPER(Err) SndStreamPause(SndStreamRef channel, Boolean pause)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(channel)	
	PACE_PARAMS_ADD8(pause)	
	PACE_EXEC(sysTrapSndStreamPause, Err)
}


PACE_CLASS_WRAPPER(Err) SndStreamStop(SndStreamRef channel)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(channel)	
	PACE_EXEC(sysTrapSndStreamStop, Err)
}

PACE_CLASS_WRAPPER(Err) SndStreamGetVolume (SndStreamRef stream,Int32 *ampScale)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(stream)
	PACE_PARAMS_ADD32(ampScale)
	PACE_EXEC_DELAY(sysTrapSndStreamGetVolume, Err)
	PACE_SWAP_OUT32(ampScale)
	PACE_RETURN()
}

PACE_CLASS_WRAPPER(Err) SndStreamSetVolume (SndStreamRef stream,Int32 ampScale)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(stream)
	PACE_PARAMS_ADD32(ampScale)
	PACE_EXEC(sysTrapSndStreamSetVolume, Err)
}

/// date/time
PACE_CLASS_WRAPPER(void) TimSecondsToDateTime(UInt32 seconds, DateTimeType *dateTimeP)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD32(seconds)
	PACE_PARAMS_ADD32(dateTimeP)
	PACE_EXEC_NRV(sysTrapTimSecondsToDateTime)
	PACE_SWAP_OUT16(&dateTimeP->day)
	PACE_SWAP_OUT16(&dateTimeP->month)
	PACE_SWAP_OUT16(&dateTimeP->year)
	PACE_SWAP_OUT16(&dateTimeP->hour)
	PACE_SWAP_OUT16(&dateTimeP->minute)
	PACE_SWAP_OUT16(&dateTimeP->second)
	PACE_SWAP_OUT16(&dateTimeP->weekDay)
}


PACE_CLASS_WRAPPER(Int16) DayOfWeek (Int16 month, Int16 day, Int16 year)
{
	PACE_PARAMS_INIT()
	PACE_PARAMS_ADD16(month)
	PACE_PARAMS_ADD16(day)
	PACE_PARAMS_ADD16(year)
	PACE_EXEC(sysTrapDayOfWeek,Int16)
}

//// HEROCRAFT HACK END ////