#ifndef PACEINTERFACE_H_
#define PACEINTERFACE_H_

// PACEInterface.h
//
// simple object wrapper for making calls into the PACE layer from your PACE Native Object
//
// Copyright (C) 2002-2003 Metrowerks Corp.

// many structure definitions be laid out incorrectly since the
// PACE Native Object compiler doesn't support 68K-compatible alignment options
// in CodeWarrior for Palm OS V9.2
//
// structures that are aligned the same from 68K to ARM:
//     RGBColorType
//     AbsRectType
//     PointType
//     RectangleType
//     DmSearchStateType
//     SortRecordInfoType
//
// Most other structures are opaque anyway, so alignment isn't an issue between
// 68K and ARM-based code.

#ifdef __cplusplus
    extern "C" {
#endif
#include <PalmOS.h>
#include <PceNativeCall.h>
#include <VFSMgr.h>
#include "endianutils.h"

/// HEROCRAFT HACK BEGIN ///

#include <DLServer.h>
#include <StringMgr.h>
#include <BtLib.h>
#include <SystemMgr.h>

//// HEROCRAFT HACK END ////

#ifdef __cplusplus
    }
#endif

struct EmulStateType;

#ifndef PACE_INTERFACE_AS_CLASS
	#define PACE_INTERFACE_AS_CLASS		1
#endif

// For ease of use, you can derive most of your PACE Native Object functionality in an object that
// inherits from this class.  Your main PACE Native Object wrapper would instantiate your
// derived object and call its main method, after constructing the object with the
// emulation state and callback function pointers passed to the entry routine.  You can
// then call Palm OS functions like you would in normal Palm OS code, although you really
// are making method calls to yourself, using the hidden "this" pointer to get at these
// system quantities.

#if PACE_INTERFACE_AS_CLASS

class PACEInterface
{
	public:
		// constructor
		PACEInterface(const void *emulStateP, Call68KFuncType *call68KFuncP) :
			m_emulStateP(const_cast<EmulStateType *>(static_cast<const EmulStateType *>(emulStateP))),
			m_call68KFuncP(call68KFuncP) { }

		// Wrapper to call other 68K functions
		UInt32 call_68K(unsigned long trapOrFunction, const void *argsOnStackP, unsigned long argsSizeAndwantA0)
		{ return m_call68KFuncP(
			static_cast<void *>(m_emulStateP), trapOrFunction,
			argsOnStackP, argsSizeAndwantA0); }

/// HEROCRAFT HACK BEGIN ///

		Err EvtResetAutoOffTimer(void);


		MemPtr BmpGetBits(BitmapType * bitmapP);
		void EvtAddEventToQueue(const EventType *event);
		void EvtGetEvent (EventType *event, Int32 timeout);
		void FrmCloseAllForms (void);
		Boolean FrmDispatchEvent (EventType *eventP);
		void FrmDrawForm (FormType *formP);
		FormType * FrmGetActiveForm (void);
		FormType *FrmGetFirstForm (void);
		void FrmGetFormBounds (const FormType *formP, RectangleType *rP);
		FormType *FrmGetFormPtr (UInt16 formId);
		void FrmGotoForm (UInt16 formId);
		FormType * FrmInitForm (UInt16 rscID);
		void FrmSetActiveForm (FormType *formP);
		void FrmSetEventHandler (FormType *formP, FormEventHandlerType *handler);
		UInt32	KeyCurrentState(void);
		UInt32	KeySetMask(UInt32 keyMask);
		Boolean MenuHandleEvent (MenuBarType *menuP, EventType *event, UInt16 *error);
		Boolean	SysHandleEvent(EventPtr eventP);
		UInt16 SysTicksPerSecond();
		UInt32 TimGetTicks(void);

		void WinCopyRectangle (WinHandle srcWin, WinHandle dstWin,
		const RectangleType *srcRect, Coord destX, Coord destY, WinDrawOperation mode);

		WinHandle WinCreateOffscreenWindow (Coord width, Coord height,
		WindowFormatType format, UInt16 *error);

		void WinDeleteWindow (WinHandle winHandle, Boolean eraseIt);

		BitmapType *WinGetBitmap (WinHandle winHandle);

		void EvtGetPen(Int16 *pScreenX, Int16 *pScreenY, Boolean *pPenDown);

		void WinGetDisplayExtent (Coord *extentX, Coord *extentY);
		
		void WinSetBackColorRGB (const RGBColorType* newRgbP, RGBColorType* prevRgbP);
		
		///file system
		Err FileControl(FileOpEnum op, FileHand stream, void *valueP, Int32 *valueLenP);
		Err FileSeek(FileHand stream, Int32 offset, FileOriginEnum origin);
		Err FileTruncate(FileHand stream, Int32 newSize);
		Int32 FileTell(FileHand stream, Int32 *fileSizeP, Err *errP);

		// HotSync
		Err DlkGetSyncInfo (UInt32 *succSyncDateP, UInt32 *lastSyncDateP,
		DlkSyncStateType *syncStateP, Char *nameBufP, Char *logBufP, Int32 *logLenP);
		Int32 StrAToI (const Char *str);
		
		///BLUETOOTH
		Err BtLibRegisterManagementNotification (UInt16 btLibRefNum, BtLibManagementProcPtr callbackP, UInt32 refCon);
		Err BtLibUnregisterManagementNotification(UInt16 btLibRefNum, BtLibManagementProcPtr callbackP);
		
		//piconet related
		Err BtLibPiconetCreate (UInt16 btLibRefNum, Boolean unlockInbound, Boolean discoverable);
		Err BtLibPiconetDestroy(UInt16 btLibRefNum);

		//inquiry related
		Err BtLibStartInquiry(UInt16 btLibRefNum,  UInt8 timeOut, UInt8 maxResp);
		Err BtLibCancelInquiry(UInt16 btLibRefNum);

		Err BtLibGetRemoteDeviceName(UInt16 btLibRefNum, BtLibDeviceAddressTypePtr remoteDeviceP,
			BtLibFriendlyNameType* nameP, BtLibGetNameEnum retrievalMethod);

		//ACL link related
		Err BtLibLinkConnect(UInt16 btLibRefNum, BtLibDeviceAddressTypePtr remoteDeviceP);
		Err BtLibLinkDisconnect(UInt16 btLibRefNum, BtLibDeviceAddressTypePtr remoteDeviceP);

		//socket related
		Err BtLibSocketCreate(UInt16 btLibRefNum, BtLibSocketRef* socketRefP,
				BtLibSocketProcPtr callbackP, UInt32 refCon, BtLibProtocolEnum socketProtocol);
		Err BtLibSocketClose(UInt16 btLibRefNum, BtLibSocketRef socket);
		Err BtLibSocketListen(UInt16 btLibRefNum, BtLibSocketRef socket, BtLibSocketListenInfoType *listenInfo);
		Err BtLibSocketConnect(UInt16 btLibRefNum, BtLibSocketRef socket, BtLibSocketConnectInfoType* connectInfo);
		Err BtLibSocketRespondToConnection(UInt16 btLibRefNum, BtLibSocketRef socket, Boolean accept);
		Err BtLibSocketSend(UInt16 btLibRefNum, BtLibSocketRef socket, UInt8 *data, UInt32 dataLen);
		Err BtLibSocketAdvanceCredit(UInt16 btLibRefNum, BtLibSocketRef socket, UInt8 credit);
		Err BtLibSocketGetInfo(UInt16 btLibRefNum, BtLibSocketRef socket,
				BtLibSocketInfoEnum infoType, void * valueP, UInt32 valueSize);

		//sdp related
		Err BtLibSdpGetServerChannelByUuid(UInt16 btLibRefNum, BtLibSocketRef socket,
		 	BtLibDeviceAddressType *rDev, BtLibSdpUuidType* serviceUUIDList, UInt8 uuidListLen);
		Err BtLibSdpServiceRecordCreate(UInt16 btLibRefNum, BtLibSdpRecordHandle* recordH);
		Err BtLibSdpServiceRecordDestroy(UInt16 btLibRefNum, BtLibSdpRecordHandle recordH);
		Err BtLibSdpServiceRecordStartAdvertising(UInt16 btLibRefNum, BtLibSdpRecordHandle recordH);
		Err BtLibSdpServiceRecordStopAdvertising(UInt16 btLibRefNum, BtLibSdpRecordHandle recordH);
		Err BtLibSdpServiceRecordSetAttributesForSocket( UInt16 btLibRefNum,   BtLibSocketRef socket,
			BtLibSdpUuidType* serviceUUIDList, UInt8 uuidListLen, const Char* serviceName, UInt16 serviceNameLen,
			BtLibSdpRecordHandle recordH);
		///BLUETOOTH End

		/// sound
		Err SndStreamCreate (SndStreamRef *stream, SndStreamMode mode, UInt32 sampleRate,
				SndSampleType type, SndStreamWidth width, SndStreamBufferCallback callback,
				void *callbackArg, UInt32 bufferSize, Boolean callbackIsARM);
		Err SndStreamDelete(SndStreamRef channel);
		Err SndStreamStart(SndStreamRef channel);
		Err SndStreamPause(SndStreamRef channel, Boolean pause);
		Err SndStreamStop(SndStreamRef channel);
		Err SndStreamSetVolume (SndStreamRef stream,Int32 ampScale);
		Err SndStreamGetVolume (SndStreamRef stream,Int32 *ampScale);

		///memory
		Err	MemHeapFreeBytes(UInt16 heapID, UInt32 *freeP, UInt32 *maxP);
		UInt16 MemHeapID(UInt16 cardNo, UInt16 heapIndex);

		///date/time
		void TimSecondsToDateTime(UInt32 s, DateTimeType *dateTimeP);		
		Int16 DayOfWeek (Int16 month, Int16 day, Int16 year);	

		Err FileDelete(UInt16 cardNo, const Char *nameP);
		FileHand FileOpen(UInt16 cardNo, const Char * nameP, UInt32 type, UInt32 creator, UInt32 openMode, Err *errP);
		Err FileClose(FileHand stream);
		Int32 FileWrite(FileHand stream, const void *dataP, Int32 objSize, Int32 numObj, Err *errP);
		Int32 FileReadLow(FileHand stream, void *baseP, Int32 offset, Boolean dataStoreBased, Int32 objSize, Int32 numObj, Err *errP);

		MemPtr MemChunkNew(UInt16 heapID, UInt32 size, UInt16 attr);
		
		WinHandle WinGetDisplayWindow (void);

//// HEROCRAFT HACK END ////

		// Memory Manager methods
		MemPtr		MemPtrNew(UInt32 size);
		Err			MemPtrFree(MemPtr ptr);
		Err			MemPtrResize(MemPtr ptr, UInt32 newSize);
		UInt32		MemPtrSize(MemPtr ptr);
		Err			MemPtrUnlock(MemPtr ptr);
		MemHandle	MemPtrRecoverHandle(MemPtr ptr);
		MemHandle	MemHandleNew(UInt32 size);
		Err			MemHandleFree(MemHandle handle);
		MemPtr		MemHandleLock(MemHandle handle);
		Err			MemHandleUnlock(MemHandle handle);
		UInt32		MemHandleSize(MemHandle handle);
		Err			MemHandleResize(MemHandle handle, UInt32 newSize);
		Err			MemMove(void *dstP, const void *sP, Int32 numBytes);
		Err			MemSet(void *dstP, Int32 numBytes, UInt8 value);
		Int16		MemCmp (const void *s1, const void *s2, Int32 numBytes);

		// Data Manager methods
		Err			DmCreateDatabase(UInt16 cardNo, const Char *nameP, UInt32 creator, UInt32 type, Boolean resDB);
		DmOpenRef	DmOpenDatabase(UInt16 cardNo, LocalID dbID, UInt16 mode);
		DmOpenRef	DmOpenDatabaseByTypeCreator(UInt32 type, UInt32 creator, UInt16 mode);
		LocalID		DmFindDatabase(UInt16 cardNo, const Char *nameP);
		Err			DmCloseDatabase(DmOpenRef dbP);
		MemHandle	DmGetRecord(DmOpenRef dbP, UInt16 index);
		MemHandle	DmQueryRecord(DmOpenRef dbP, UInt16 index);
		Err			DmReleaseRecord(DmOpenRef dbP, UInt16 index, Boolean dirty);
		MemHandle	DmNewRecord(DmOpenRef dbP, UInt16 *atP, UInt32 size);
		Err			DmRecordInfo(DmOpenRef dbP, UInt16 index, UInt16 *attrP, UInt32 *uniqueIDP, LocalID *chunkIDP);
		Err			DmSetRecordInfo(DmOpenRef dbP, UInt16 index, UInt16 *attrP, UInt32 *uniqueIDP);
		Err			DmStrCopy(void *recordP, UInt32 offset, const Char *srcP);
		Err			DmWrite(void *recordP, UInt32 offset, const void *srcP, UInt32 bytes);
		Err			DmWriteCheck(void *recordP, UInt32 offset, UInt32 bytes);
		Err			DmSet(void *recordP, UInt32 offset, UInt32 bytes, UInt8 value);
		MemHandle	DmResizeRecord(DmOpenRef dbP, UInt16 index, UInt32 newSize);
		Err			DmRemoveRecord(DmOpenRef dbP, UInt16 index);
		Err			DmDeleteRecord(DmOpenRef dbP, UInt16 index);
		Err			DmArchiveRecord(DmOpenRef dbP, UInt16 index);
		Err			DmFindRecordByID(DmOpenRef dbP, UInt32 uniqueID, UInt16 *indexP);
		Err			DmMoveRecord(DmOpenRef dbP, UInt16 from, UInt16 to);
		Err			DmDeleteDatabase(UInt16 cardNo, LocalID dbID);
		Err			DmGetNextDatabaseByTypeCreator(Boolean newSearch, DmSearchStatePtr stateInfoP,
						UInt32	type, UInt32 creator, Boolean onlyLatestVers,
						UInt16 *cardNoP, LocalID *dbIDP);
		Err			DmDatabaseInfo(UInt16 cardNo, LocalID	dbID, Char *nameP,
						UInt16 *attributesP, UInt16 *versionP, UInt32 *crDateP,
						UInt32 *	modDateP, UInt32 *bckUpDateP,
						UInt32 *	modNumP, LocalID *appInfoIDP,
						LocalID *sortInfoIDP, UInt32 *typeP,
						UInt32 *creatorP);
		Err			DmDatabaseSize(UInt16 cardNo, LocalID dbID, UInt32 *numRecordsP,
						UInt32 *	totalBytesP, UInt32 *dataBytesP);
		MemHandle	DmResizeResource(MemHandle resourceH, UInt32 newSize);
		MemHandle	DmGetResourceIndex(DmOpenRef dbP, UInt16 index);
		MemHandle	DmGetResource(DmResType type, DmResID ID);
		Err			DmReleaseResource(MemHandle rsrcH);
		UInt16		DmFindResource(DmOpenRef dbP, DmResType resType, DmResID resID, MemHandle resH);
		Err			DmRemoveResource(DmOpenRef dbP, UInt16 index);

		// VFS Manager methods
		Err 		VFSFileOpen(UInt16 volRefNum, const Char *pathNameP, UInt16 openMode, FileRef *fileRefP);
	    Err 		VFSFileCreate(UInt16 volRefNum, const Char *pathNameP);
		Err 		VFSFileClose(FileRef fileRef);
		Err 		VFSFileRead(FileRef fileRef, UInt32 numBytes, void *bufP, UInt32 *numBytesReadP);
		Err 		VFSFileSeek(FileRef fileRef, UInt16 origin, Int32 offset);
		Err 		VFSFileTell(FileRef fileRef, UInt32 *filePosP);
	    Err 		VFSFileReadData(FileRef fileRef, UInt32 numBytes, void *bufBaseP, UInt32 offset, UInt32 *numBytesReadP);
	    Err 		VFSFileWrite(FileRef fileRef, UInt32 numBytes, const void *dataP, UInt32 *numBytesWrittenP);
	    Err 		VFSFileSize(FileRef fileRef, UInt32 *fileSizeP);
	    Err 		VFSFileResize(FileRef fileRef, UInt32 newSize);
	
	    // Debug Manager methods
		void 		DbgMessage(const Char *aStr);
	
		// System Manager methods
		Int16		SysRandom(Int32 newSeed);

		// Window Manager methods
		void		WinSetForeColorRGB(const RGBColorType* newRgbP, RGBColorType* prevRgbP);
		void		WinDrawPixel(Coord x, Coord y);
		void		WinPushDrawState(void);
		void		WinPopDrawState(void);
		WinDrawOperation WinSetDrawMode(WinDrawOperation newMode);
		IndexedColorType WinSetForeColor(IndexedColorType foreColor);
		IndexedColorType WinSetBackColor(IndexedColorType backColor);
		IndexedColorType WinSetTextColor(IndexedColorType textColor);
		Err WinPalette(UInt8 operation, Int16 startIndex,
			UInt16 paletteEntries, RGBColorType *tableP);
		void WinDrawChar (WChar theChar, Coord x, Coord y);
		void WinDrawChars (const Char *chars, Int16 len, Coord x, Coord y);
		void WinPaintChar (WChar theChar, Coord x, Coord y);
		void WinPaintChars (const Char *chars, Int16 len, Coord x, Coord y);
		void WinDrawInvertedChars (const Char *chars, Int16 len, Coord x, Coord y);
		void WinDrawTruncChars(const Char *chars, Int16 len, Coord x, Coord y, Coord maxWidth);
		void WinEraseChars (const Char *chars, Int16 len, Coord x, Coord y);
		void WinInvertChars (const Char *chars, Int16 len, Coord x, Coord y);
		UnderlineModeType WinSetUnderlineMode (UnderlineModeType mode);
		Err WinScreenMode(WinScreenModeOperation operation,
			UInt32 *widthP,	UInt32 *heightP,
			UInt32 *depthP,	Boolean *enableColorP);
		WinHandle WinSetDrawWindow (WinHandle winHandle);
		WinHandle WinGetDrawWindow (void);
		
		void WinPaintRectangle (const RectangleType *rP, UInt16 cornerDiam);
		void WinDrawRectangle (const RectangleType *rP, UInt16 cornerDiam);
		void WinEraseRectangle (const RectangleType *rP, UInt16 cornerDiam);
		void WinInvertRectangle (const RectangleType *rP, UInt16 cornerDiam);
		void WinFillRectangle (const RectangleType *rP, UInt16 cornerDiam);
		void WinScrollRectangle(const RectangleType *rP, WinDirectionType direction,
			Coord distance, RectangleType *vacatedP);

		// Form Manager methods
		UInt16		FrmAlert (UInt16 alertId);
		UInt16		FrmCustomAlert (UInt16 alertId, const Char *s1, const Char *s2=" ", const Char *s3=" ");

		// String Manager methods
		Char * StrIToA(Char *s, Int32 i);
		Char * StrIToH(Char *s, UInt32 i);
		Char * StrChr(const Char *str, WChar chr);
		Char * StrStr(const Char *str, const Char *token);
		Char * StrCopy(Char *dst, const Char *src);
		Char * StrNCopy(Char *dst, const Char *src, Int16 n);
		Char * StrCat(Char *dst, const Char *src);
		Char * StrNCat(Char *dst, const Char *src, Int16 n);
		UInt16 StrLen(const Char *src);
		Int16 StrCompareAscii(const Char *s1, const Char *s2);
		Int16 StrCompare(const Char *s1, const Char *s2);
		Int16 StrNCompareAscii(const Char *s1, const Char *s2, Int32 n);
		Int16 StrNCompare(const Char *s1, const Char *s2, Int32 n);
		Int16 StrCaselessCompare(const Char *s1, const Char *s2);
		Int16 StrNCaselessCompare(const Char *s1, const Char *s2, Int32 n);
		Char * StrToLower(Char *dst, const Char *src);

		// Event Manager methods
		Boolean		EvtEventAvail(void);

		// Time Manager methods
		UInt32 TimGetSeconds();

		// Preference Manager methods
		Int16 PrefGetAppPreferences(
			UInt32 creator,UInt16 id, void *prefs, UInt16 *prefsSize, Boolean saved);
		void PrefSetAppPreferences(
			UInt32 creator,UInt16 id, Int16 version, const void *prefs,
			UInt16 prefsSize, Boolean saved);
		// System Dialogs methods
		UInt16		SysFatalAlert(const Char *msg);

		// Feature Manager methods
		Err	FtrGet(UInt32 creator, UInt16 featureNum, UInt32 *valueP);
		Err	FtrSet(UInt32 creator, UInt16 featureNum, UInt32 newValue);
		Err	FtrUnregister(UInt32 creator, UInt16 featureNum);
		Err	FtrGetByIndex(UInt16 index, Boolean romTable,
							UInt32 *creatorP, UInt16 *numP, UInt32 *valueP);
		Err	FtrPtrNew(UInt32 creator, UInt16 featureNum, UInt32 size,
							void **newPtrP);
		Err	FtrPtrFree(UInt32 creator, UInt16 featureNum);
		Err	FtrPtrResize(UInt32 creator, UInt16 featureNum, UInt32 newSize,
							void **newPtrP);

		// Font Manager methods
		FontID FntGetFont(void);
		FontID FntSetFont(FontID font);
		FontPtr FntGetFontPtr (void);
		Int16 FntBaseLine(void);
		Int16 FntCharHeight(void);
		Int16 FntLineHeight(void);
		Int16 FntAverageCharWidth(void);
		Int16 FntCharWidth(Char ch);
		Int16 FntWCharWidth(WChar iChar);
		Int16 FntCharsWidth(Char const *chars, Int16 len);
		Int16 FntWidthToOffset(Char const *pChars, UInt16 length,
			Int16 pixelWidth, Boolean *leadingEdge, Int16 *truncWidth);
		void FntCharsInWidth(Char const *string,
			Int16 *stringWidthP, Int16 *stringLengthP,
			Boolean *fitWithinWidth);
		Int16 FntDescenderHeight(void);
		Int16 FntLineWidth(Char const *pChars, UInt16 length);
		UInt16 FntWordWrap(Char const *chars, UInt16 maxWidth);
		void FntWordWrapReverseNLines(Char const *const chars,
			UInt16 maxWidth, UInt16 *linesToScrollP, UInt16 *scrollPosP);
		void FntGetScrollValues(Char const *chars, UInt16 width,
			UInt16 scrollPos, UInt16 *linesP, UInt16 *topLine);
		Err FntDefineFont(FontID font, FontPtr fontP);

	protected:
		EmulStateType	*m_emulStateP;
		Call68KFuncType *m_call68KFuncP;
};

#else

#ifdef __cplusplus
extern "C"
#endif
void InitPACEInterface(const void *emulStateP, Call68KFuncType *call68KFuncP);

#endif /* PACE_INTERFACE_AS_CLASS */

#endif /* PACEINTERFACE_H_ */