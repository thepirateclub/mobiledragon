// SplitRes.c

#include <PalmOS.h>
#include "SplitRes.h"

SplitResType *SplitResOpen(DmResType resType, DmResID baseID)
{
	Err err = errNone;
	SplitResType * splitRes = NULL;
	DmResID curID = baseID; 
	MemHandle res;
	UInt16 resCount = 0;
	UInt32 totalSize = 0;
	
	// count the resources and determine total size
	while ((res = DmGetResource(resType, curID)) != NULL)
	{
		totalSize += MemHandleSize(res);
		DmReleaseResource(res);
		++curID;
	}
	
	// check for no resources found
	if (curID == baseID) return NULL;

	// allocate memory for the splitRes descriptor
	resCount = curID - baseID;
	splitRes = MemPtrNew(sizeof(SplitResType) + sizeof(UInt32) * resCount);
	
	if (splitRes != NULL)
	{
		splitRes->resType = resType;
		splitRes->baseID = baseID;
		splitRes->resCount = resCount;
		splitRes->totalSize = totalSize;

		curID = baseID;
		resCount = 0;

		// store away all the resource sizes
		while (resCount < splitRes->resCount)
		{
			res = DmGetResource(resType, curID);
			splitRes->resSize[resCount] = MemHandleSize(res);
			DmReleaseResource(res);
			++curID;
			++resCount;
		}
	}

	return splitRes;
}

void SplitResClose(SplitResType *splitRes)
{
	MemPtrFree(splitRes);
}

typedef struct CopyChunkData
{
	MemPtr dest;
	UInt32 destOffset;
} CopyChunkData;

static void CopyChunkToDynamicHeap(
	const void *chunkData, UInt32 chunkSize, void *userData)
{
	CopyChunkData *data = (CopyChunkData *)userData;
	MemMove((Char *)(data->dest) + data->destOffset, chunkData, chunkSize);
	data->destOffset += chunkSize;
}

static void CopyChunkToStorageHeap(
	const void *chunkData, UInt32 chunkSize, void *userData)
{
	CopyChunkData *data = (CopyChunkData *)userData;
	DmWrite(data->dest, data->destOffset, chunkData, chunkSize);
	data->destOffset += chunkSize;
}

Err SplitResProcessChunks(
	SplitResType *splitRes, 
	UInt32 srcOffset, UInt32 size,
	ProcessChunkFunc *func, void *userData)
{
	UInt16 resNum = 0;
	Err err = errNone;

	////////////////////////////////////////////////////////////////////////
	// fix from Ben Combee
	// was if ((srcOffset + size) >= splitRes->totalSize)
	////////////////////////////////////////////////////////////////////////
	if ((srcOffset + size) > splitRes->totalSize)
	{
		return memErrInvalidParam;
	}

	// find first resource containing offset
	while (resNum < splitRes->resCount)
	{
		if (srcOffset < splitRes->resSize[resNum])
		{
			break;
		}
			
		srcOffset -= splitRes->resSize[resNum];
		++resNum;
	}

	while (size > 0)
	{
		// copy as much as possible from this chunk then advance
		MemHandle res = DmGetResource(
			splitRes->resType, 
			splitRes->baseID + resNum);
		MemPtr srcP = MemHandleLock(res);
		
		UInt32 chunkSize = splitRes->resSize[resNum] - srcOffset;

		// truncate to size bytes if this chunk is larger than copy space
		if (chunkSize > size)
		{
			chunkSize = size;
		}

		func((Char *)srcP + srcOffset, chunkSize, userData);

		MemHandleUnlock(res);
		DmReleaseResource(res);
		srcOffset = 0;
		size -= chunkSize;
		++resNum;
	}

	return errNone;
}

Err SplitResRead(SplitResType *splitRes, 
	MemPtr dest, UInt32 destOffset,
	UInt32 srcOffset, UInt32 size)
{
	CopyChunkData copyData;
	copyData.dest = dest;
	copyData.destOffset = destOffset;
	
	return SplitResProcessChunks(splitRes, srcOffset, size, 
		CopyChunkToDynamicHeap, &copyData);
}

Err SplitResDmRead(SplitResType *splitRes, 
	MemPtr dest, UInt32 destOffset,
	UInt32 srcOffset, UInt32 size)
{
	CopyChunkData copyData;
	copyData.dest = dest;
	copyData.destOffset = destOffset;
	
	return SplitResProcessChunks(splitRes, srcOffset, size, 
		CopyChunkToStorageHeap,	&copyData);
}
